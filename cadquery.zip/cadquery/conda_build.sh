conda build conda/meta.yaml -c cadquery -c conda-forge --croot /tmp/cbld
