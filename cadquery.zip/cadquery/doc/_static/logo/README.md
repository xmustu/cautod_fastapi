## CadQuery Logo

This logo uses the Roboto bold font (included), the Inkscape font size is 56, and the color is #2980b9
