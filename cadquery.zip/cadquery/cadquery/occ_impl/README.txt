CadQuery implementation based on OCP
