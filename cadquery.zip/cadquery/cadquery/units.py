from math import pi

RAD2DEG = 180 / pi
DEG2RAD = pi / 180
