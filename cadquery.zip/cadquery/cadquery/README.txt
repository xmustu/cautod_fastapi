***
Core CadQuery implementation.

No files should depend on or import PythonOCC, or other CAD Kernel libraries!!!
Dependencies should be on the classes provided by implementation packages, which in turn 
can depend on CAD libraries.

***