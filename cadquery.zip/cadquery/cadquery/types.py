from typing import Union

Real = Union[int, float]
