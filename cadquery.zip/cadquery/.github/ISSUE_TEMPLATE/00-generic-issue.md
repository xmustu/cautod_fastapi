---
name: Generic issue
about: Use this if none of the more specific templates fit your issue
title: ''
labels: ''
assignees: ''

---

<!-- If you have a question, please first make sure it is not already answered in the README.md or https://cadquery.readthedocs.io -->
