---
name: OCCT feature request
about: Suggest an implementation of an existing OCCT feature
title: ''
labels: OCC feature, enhancement
assignees: ''

---

<!-- Describe what use cases this would have and any other relevant information. -->

Links to OCCT documentation:
*  <!-- https://old.opencascade.com/doc/occt-7.5.0/refman/html/ -->
